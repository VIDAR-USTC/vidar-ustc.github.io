function  [Y]  =  GIm2Patch3D( LF,patchsize)
% get full band patches
%cubesize     = par.patsize;
step        = 1;
TotalPatNum = (floor((size(LF,1)-patchsize)/step)+1)*(floor((size(LF,2)-patchsize)/step)+1);                  %Total Patch Number in the image
Y           =   zeros(patchsize*patchsize,  TotalPatNum);                                       %Patches in the original noisy image

k           =   0;
for i  = 1:patchsize
    for j  = 1:patchsize
        k     =  k+1;
        tempPatch     =  LF(i:step:end-patchsize+i,j:step:end-patchsize+j);
        Y(k,:) = tempPatch(:);%ÿһ���������в������п��ͬһ��λ�õĵ���ɵĶ�ά����
    end
end
Y = reshape(Y,patchsize,patchsize,TotalPatNum);
end         %Estimated Local Noise Level