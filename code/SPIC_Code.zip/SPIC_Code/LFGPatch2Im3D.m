function  [E_Img]  =  LFGPatch2Im3D( ImPat, WPat, par, sizeV )
%WPat=permute(WPat,[1,3,2]);
patsize      = par.patsize;
if isfield(par,'Pstep')
    step   = par.Pstep;
else
    step   = 1;
end
sm    = size(ImPat);
ImPat = reshape(ImPat,sm(1)*sm(2),sm(3),sm(4),sm(5));
WPat  = reshape(WPat,sm(1)*sm(2),sm(3),sm(4),sm(5));
TempR        =   floor((sizeV(1)-patsize)/step)+1;
TempC        =   floor((sizeV(2)-patsize)/step)+1;
TempOffsetR  =   1:step:(TempR-1)*step+1;
TempOffsetC  =   1:step:(TempC-1)*step+1;

E_Img  	=  zeros(sizeV);
W_Img 	=  zeros(sizeV);

for ver = 1:sizeV(3)
    for hon = 1:sizeV(4)
        k        =   0;
        for i  = 1:patsize
            for j  = 1:patsize
                k    =  k+1;
                E_Img(TempOffsetR-1+i,TempOffsetC-1+j,ver,hon)  =  E_Img(TempOffsetR-1+i,TempOffsetC-1+j,ver,hon) + Fold( ImPat(k,:,ver,hon), [TempR TempC ], 3);
                W_Img(TempOffsetR-1+i,TempOffsetC-1+j,ver,hon)  =  W_Img(TempOffsetR-1+i,TempOffsetC-1+j,ver,hon) + reshape(WPat(k,:,ver,hon),[TempR,TempC]);%reshape( WPat(k,:)',  [TempR TempC]);
            end
        end
    end
end
E_Img  =  E_Img./(W_Img+eps);
Weight =  1./(W_Img);


