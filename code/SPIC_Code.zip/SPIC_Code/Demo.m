addpath(genpath('Disparity_Estimation_Code'));
clear all;


dataset(1).name = 'pillows';

filename = 'HCI_new_data_noisy_image_0_25';
if  ~exist(filename,'dir')
    mkdir(filename);
end

filename_para = 'HCI_new_data_noisy_image_0_25_para';
if  ~exist(filename_para,'dir')
    mkdir(filename_para);
end

filename_step1 = 'HCI_new_data_noisy_image_0_25_step1';
if  ~exist(filename_step1,'dir')
    mkdir(filename_step1);
end


filename_step2 = 'HCI_new_data_noisy_image_0_25_step2';
if  ~exist(filename_step2,'dir')
    mkdir(filename_step2);
end


for image = 1:1
    sigma = 0.25;
%     load([num2str(dataset(image).name),'_crop.mat']);
     load(['HCI_new_data_org\',num2str(dataset(image).name),'.mat']);
    Olf = Olf(129:384,129:384,:,:,:);
    si    = size(Olf);
    disp( ['=== The variance of noise is ',num2str(sigma),' ===']);
    YcbcrOlf = zeros(si);
    for u = 1:si(3)
        for v = 1:si(4)
            YcbcrOlf(:,:,u,v,:) = rgb2ycbcr(squeeze(Olf(:,:,u,v,:)));
        end
    end
    G_Olf                             = YcbcrOlf(:,:,:,:,1);
    G_Nlf                             = G_Olf+ sigma*randn(size(G_Olf));
    save(['G_Nlf_',num2str(dataset(image).name,'.mat')],'G_Nlf');
    psnr_noisy                        = PSNR4D(G_Olf*255,G_Nlf*255);
    G_Elf                             = G_Nlf;
    [par,parBSM]                      = ParSet_New(sigma);
    R_num                             = si(1)-par.patsize+1;
    C_num                             = si(2)-par.patsize+1;
    [Sel_arr,R,C,C_GridIdx,R_GridIdx] = nonLocal_arr(si,par);
    L                                 = length(Sel_arr);
    si                                = size(G_Elf);
    disp(['psnr_noisy = ', num2str(psnr_noisy)]);
    %% ----------Step1----------
    % disp('-------Denoising LF image Step1-------');
    for iter = 1:par.deNoisingIter
        G_Elf    = G_Elf+par.delta*(G_Nlf-G_Elf);
        Curpatch = LFGIm2Patch3D(G_Elf,par.patsize);%11*11*similarNum*U*V
        sc       = size(Curpatch);
        G_Elf    = reshape(G_Elf,si(1),si(2),si(3)*si(4));
        index    = similar_cube(G_Elf,Sel_arr,par,R,C,R_num,si(1),si(2),C_GridIdx,R_GridIdx);
        save(['index',num2str(dataset(image).name),'_',num2str(iter),'.mat'],'index');
        Curpatch = reshape(Curpatch,sc(1),sc(2),sc(3),sc(4)*sc(5));
        sc       = size(Curpatch);
        if iter~=par.deNoisingIter
            parBSM.maxIter = 6;
        else
            parBSM.maxIter = 25;
        end
        if(iter == 1)
            Sigma_arr = par.SigLam*par.nSig * ones(sc(4),L); % First Iteration use the input noise parameter
        else
            Npatch   = LFGIm2Patch3D(G_Nlf,par.patsize);
            Npatch   = reshape(Npatch,sc(1),sc(2),sc(3),sc(4));
            for view = 1:sc(4)
                temp(:,view)        = sum(sum((Curpatch(:,:,Sel_arr,view)-Npatch(:,:,Sel_arr,view)).^2,1),2)/prod(sc(1:2));%%%%
                Sigma_arr(view,:)   = par.SigLam*sqrt(abs(par.nSig^2*ones(1,L)- temp(:,view)')); % estimate local noise variance
            end
            clear Npatch temp;
        end
        clear T;
        sizeInd  = size(index);
        Epatch   = zeros(sc(1),sc(2),sc(3),sc(4));
        W        = zeros(sc(1),sc(2),sc(3),sc(4));
        for view = 1:sc(4)
            tic;
            tempPatch   = Curpatch(:,:,reshape(index(view,:,:),sizeInd(2)*sizeInd(3),1));
            tempPatch   = reshape(tempPatch,[sc(1:2),sizeInd(2:3)]);
            st          = size(tempPatch);
            parfor j = 1:sizeInd(3)
                tempPatch(:,:,:,j) = ITSReg(tempPatch(:,:,:,j),1/Sigma_arr(view,j),parBSM);
            end
            for j = 1:L
                Epatch(:,:,index(view,:,j)) = Epatch(:,:,index(view,:,j)) +tempPatch(:,:,:,j);
                W(:,:,index(view,:,j))      = W(:,:,index(view,:,j)) + ones(st(1),st(2),st(3));
                
            end
            toc;
        end
        Epatch = reshape(Epatch,sc(1),sc(2),sc(3),si(3),si(4));
        W      = reshape(W,sc(1),sc(2),sc(3),si(3),si(4));
        G_Elf  = LFGPatch2Im3D( Epatch, W, par, si);
        clear W Epatch;
        psnr_step1(image,iter) = PSNR4D(G_Olf * 255,G_Elf * 255);
        save([num2str(dataset(image).name),'_',num2str(sigma*100),'_',num2str(iter),'.mat'],'G_Elf');
        disp(['Step1 : psnr_clear',num2str(iter),' = ',num2str(psnr_step1(image,iter))]);
        clear W Epatch ;
        
    end

    [HR_GElf,disparity,deleted_points,save_Mesh_X,save_Mesh_Y,save_Mesh_V] = SR_denoised_y(G_Elf);    

    %% HR image denoising
    sigma_temp = sqrt(sum((G_Elf(:) - G_Nlf(:)).^2)/prod(si));
    sigma_add  = sqrt(abs(sigma^2 - sigma_temp^2));    
    [par,parBSM]                      = ParSet_New(sigma_add);  
    par.window = 3 * (par.window - 1) + 1;
    %% HR image denoising
    HR_GNlf                            = HR_GElf;
    R_num                              = HR_si(1)-par.patsize+1;
    [Sel_arr,R,C,C_GridIdx,R_GridIdx]  = nonLocal_arr(HR_si,par);
    L                                  = length(Sel_arr);
    for iter = 1:1
        HR_GElf = HR_GElf+par.delta*(HR_GNlf-HR_GElf);
        index   = HR_similar_cube(HR_GElf,Sel_arr,par,R,C,R_num,HR_si(1),HR_si(2),C_GridIdx,R_GridIdx);
        if(iter == 1)
            parBSM.maxIter = 15;
        else
            parBSM.maxIter = 25;
        end
        Curpatch  = GIm2Patch3D(HR_GElf, par.patsize);
        sc        = size(Curpatch);
        Npatch    = GIm2Patch3D(HR_GNlf,par.patsize);
        if(iter == 1)
            Sigma_arr = par.SigLam*sigma_add * ones(1,L);
        else
            temp      = sum(sum((Curpatch(:,:,Sel_arr)-Npatch(:,:,Sel_arr)).^2,1),2)/prod(sc(1:2));
            Sigma_arr = par.SigLam*sqrt(abs(sigma_add^2*ones(1,L)- temp(:)')); % estimate local noise variance
        end
        sizeInd   = size(index);
        Epatch    = zeros(sc(1),sc(2),sc(3));
        W         = zeros(sc(1),sc(2),sc(3));
        tempPatch = Curpatch(:,:,reshape(index(:,:),sizeInd(1)*sizeInd(2),1));
        tempPatch = reshape(tempPatch,[sc(1:2),sizeInd(1:2)]);
        st        = size(tempPatch);
        parfor j = 1:sizeInd(2)
            tempPatch(:,:,:,j)=ITSReg(tempPatch(:,:,:,j),1/Sigma_arr(j),parBSM);
        end
        for j = 1:L
            Epatch(:,:,index(:,j)) = Epatch(:,:,index(:,j)) + tempPatch(:,:,:,j);
            W(:,:,index(:,j))      = W(:,:,index(:,j)) + ones(st(1),st(2),st(3));
        end
        clear tempPatch tempSigma  Sigma_arr Curpatch;
        HR_GElf    = GPatch2Im3D( Epatch, W, par, HR_si);
        clear W Epatch;
    end
    %% back projection
    LR_GElf    = bp_projection(si(3),si(4),HR_GElf,disparity,deleted_points,save_Mesh_X,save_Mesh_Y,save_Mesh_V);
    LR_GElf    = permute(LR_GElf,[3,4,1,2]);
    psnr_clear_denoised2(image) = PSNR4D(G_Olf*255,LR_GElf*255);
    disp(['Step2 : psnr_clear' ,'= ',num2str(psnr_clear_denoised2(image))]);
    save([num2str(dataset(image).name),'_denoised2_estimate_iter1_15.mat'],'LR_GElf');
end


return;