function  [Y]  =  LFGIm2Patch3D( LF,patchsize)
% get full band patches
%cubesize     = par.patsize;
step        = 1;
TotalPatNum = (floor((size(LF,1)-patchsize)/step)+1)*(floor((size(LF,2)-patchsize)/step)+1);                  %Total Patch Number in the image
Y           =   zeros(patchsize*patchsize,  TotalPatNum,size(LF,3),size(LF,4));                                       %Patches in the original noisy image

for ver=1:size(LF,3)    
    for hon=1:size(LF,4)
        k           =   0;
        for i  = 1:patchsize
            for j  = 1:patchsize
                k     =  k+1;
                tempPatch     =  LF(i:step:end-patchsize+i,j:step:end-patchsize+j,ver,hon);
                Y(k,:,ver,hon) = tempPatch(:);
            end
        end
    end
end
Y = reshape(Y,patchsize,patchsize,TotalPatNum,size(LF,3),size(LF,4));
end         %Estimated Local Noise Level