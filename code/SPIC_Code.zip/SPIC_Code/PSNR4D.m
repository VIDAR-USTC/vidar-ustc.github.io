function [psnr]  =  PSNR4D(imagery1,imagery2)
[H,W,U,V,~] = size(imagery1);

psnr = 0;
for u = 1:U
        for v = 1:V
            T1=squeeze(imagery1(:, :, u,v,:));
            T2=squeeze(imagery2(:, :, u,v,:));
            p(u,v) = 10*log10(255^2/mse(T1(:) - T2(:)));
            psnr = psnr + p(u,v);
        end
end

psnr = psnr/(U*V);
end