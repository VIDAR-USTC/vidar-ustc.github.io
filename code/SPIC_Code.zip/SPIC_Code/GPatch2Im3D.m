function  [E_Img]  =  GPatch2Im3D( ImPat, WPat, par, sizeV )
%WPat=permute(WPat,[1,3,2]);
patsize      = par.patsize;
if isfield(par,'Pstep')
    step   = par.Pstep;
else
    step   = 1;
end
sm    = size(ImPat);
ImPat = reshape(ImPat,sm(1)*sm(2),sm(3));
WPat  = reshape(WPat,sm(1)*sm(2),sm(3));
TempR        =   floor((sizeV(1)-patsize)/step)+1;
TempC        =   floor((sizeV(2)-patsize)/step)+1;
TempOffsetR  =   1:step:(TempR-1)*step+1;
TempOffsetC  =   1:step:(TempC-1)*step+1;

E_Img  	=  zeros(sizeV);
W_Img 	=  zeros(sizeV);

        k        =   0;
        for i  = 1:patsize
            for j  = 1:patsize
                k    =  k+1;
                E_Img(TempOffsetR-1+i,TempOffsetC-1+j)  =  E_Img(TempOffsetR-1+i,TempOffsetC-1+j) + Fold( ImPat(k,:), [TempR TempC ], 3);
                W_Img(TempOffsetR-1+i,TempOffsetC-1+j)  =  W_Img(TempOffsetR-1+i,TempOffsetC-1+j) + reshape(WPat(k,:),[TempR,TempC]);%reshape( WPat(k,:)',  [TempR TempC]);
            end
        end

E_Img  =  E_Img./(W_Img+eps);
% Weight =  1./(W_Img);
end


