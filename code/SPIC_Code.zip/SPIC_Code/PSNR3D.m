function [psnr ]  =  PSNR3D(imagery1,imagery2)
[m, n, k,v,h] = size(imagery1);
% [mm, nn, kk,] = size(imagery2);
% m = min(m, mm);
% n = min(n, nn);
% k = min(k, kk);
% imagery1 = imagery1(1:m, 1:n, 1:k,:,:);
% imagery2 = imagery2(1:m, 1:n, 1:k,:,:);
psnr = 0;
for ver = 1:v
    for hon = 1:h
        for i = 1:k
            
            p(ver,hon,i) = 10*log10(255^2/mse(imagery1(:, :, i,ver,hon) - imagery2(:, :, i,ver,hon)));
            psnr = psnr + p(ver,hon,i);
        end
    end
end
psnr = psnr/(k*v*h);

end